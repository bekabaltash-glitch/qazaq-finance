'use strict';

// ── Data ──────────────────────────────────────────────────────────────────────
const CATEGORIES = {
  salary:        { label: 'Жалақы',        icon: '💼', type: 'income'  },
  freelance:     { label: 'Фриланс',        icon: '💻', type: 'income'  },
  gift:          { label: 'Сыйлық',         icon: '🎁', type: 'income'  },
  other_income:  { label: 'Басқа кіріс',    icon: '📥', type: 'income'  },
  food:          { label: 'Тамақ',          icon: '🍔', type: 'expense' },
  transport:     { label: 'Көлік',          icon: '🚗', type: 'expense' },
  shopping:      { label: 'Сатып алу',      icon: '🛍️', type: 'expense' },
  health:        { label: 'Денсаулық',      icon: '💊', type: 'expense' },
  entertainment: { label: 'Ойын-сауық',     icon: '🎬', type: 'expense' },
  utilities:     { label: 'Коммуналдық',    icon: '🏠', type: 'expense' },
  education:     { label: 'Білім',          icon: '📚', type: 'expense' },
  other:         { label: 'Басқа шығыс',    icon: '📁', type: 'expense' },
};

const INVESTMENTS = [
  { icon: '🏦', title: 'Депозит',                subtitle: 'Банктік салым',         desc: 'Ең қауіпсіз тәсіл. Банкке ақша салып, жыл сайын 10–14% пайыз аласыз. Сомасы мен мерзімі алдын ала белгіленеді.',            risk: 'low', riskLabel: 'Тәуекел: төмен'   },
  { icon: '📊', title: 'Акция',                  subtitle: 'Компания үлесі',         desc: 'Компания үлесін сатып аласыз. Компания өскен сайын ақшаңыз да өседі. Бірақ баға төмендеуі де мүмкін.',                       risk: 'high', riskLabel: 'Тәуекел: жоғары' },
  { icon: '📜', title: 'Облигация',              subtitle: 'Мемлекет/компания қарызы', desc: 'Мемлекетке немесе компанияға уақытша ақша беріп, белгіленген пайыз аласыз. Акциядан қауіпсіздеу.',                        risk: 'mid',  riskLabel: 'Тәуекел: орташа' },
  { icon: '🏠', title: 'Жылжымайтын мүлік',      subtitle: 'Пәтер / жер',            desc: 'Пәтер немесе жер алып, жалға беруден табыс табасыз. Қазақстанда ең танымал инвестиция түрі.',                               risk: 'mid',  riskLabel: 'Тәуекел: орташа' },
  { icon: '💱', title: 'Валюта',                 subtitle: 'Шет ел ақшасы',          desc: 'Доллар, евро немесе басқа валюта сатып алып, бағамның өсуінен пайда табасыз. Болжау қиын.',                                  risk: 'high', riskLabel: 'Тәуекел: жоғары' },
  { icon: '🪙', title: 'Криптовалюта',           subtitle: 'Цифрлық актив',          desc: 'Bitcoin, Ethereum сияқты цифрлық валюталар. Өте жоғары тәуекел, бірақ үлкен пайда мүмкіндігі бар.',                          risk: 'high', riskLabel: 'Тәуекел: жоғары' },
];

const TIPS = [
  { title: '50/30/20 ережесі',       text: 'Кірісіңіздің 50% — қажеттілік, 30% — ләззат, 20% — жинақ. Бұл балансты сақтауға тырысыңыз.' },
  { title: 'Алдымен өзіңізге төлеңіз', text: 'Жалақы алған бойда жинаққа бөлуді автоматтандырыңыз. Қалғанын ғана жұмсаңыз.' },
  { title: 'Апаттық қор жасаңыз',    text: '3–6 айлық шығысыңыздай апаттық қор болуы керек. Ол арнайы шотта тұруы тиіс.' },
  { title: 'Кішкентай бастаңыз',     text: 'Инвестицияны үлкен сомадан бастау шарт емес. Айына 5 000–10 000 ₸ салып үйреніңіз.' },
];

// ── State ─────────────────────────────────────────────────────────────────────
let transactions = JSON.parse(localStorage.getItem('qf_transactions') || '[]');
let currentType = 'income';

function save() {
  localStorage.setItem('qf_transactions', JSON.stringify(transactions));
}

function fmt(n) {
  return new Intl.NumberFormat('kk-KZ').format(Math.round(n)) + ' ₸';
}

// ── Navigation ────────────────────────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('screen-' + tab).classList.add('active');
  document.getElementById('nav-' + tab).classList.add('active');

  const fab = document.getElementById('fab');
  fab.style.display = tab === 'budget' ? 'flex' : 'none';

  if (tab === 'stats') renderStats();
}

// ── Budget ────────────────────────────────────────────────────────────────────
function renderBudget() {
  const income  = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const balance = income - expense;

  document.getElementById('balance-amount').textContent = fmt(balance);
  document.getElementById('income-total').textContent   = fmt(income);
  document.getElementById('expense-total').textContent  = fmt(expense);

  const list = document.getElementById('txn-list');
  if (transactions.length === 0) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">💸</div>Операциялар жоқ.<br>+ батырмасын басып қосыңыз.</div>';
    return;
  }

  list.innerHTML = [...transactions].reverse().map(t => {
    const cat  = CATEGORIES[t.category] || CATEGORIES.other;
    const sign = t.type === 'income' ? '+' : '−';
    const cls  = t.type === 'income' ? 'income-color' : 'expense-color';
    const bg   = t.type === 'income' ? 'var(--color-income-bg)' : 'var(--color-expense-bg)';
    return `<div class="txn-card">
      <div class="txn-icon" style="background:${bg}">${cat.icon}</div>
      <div class="txn-info">
        <div class="txn-name">${escHtml(t.name)}</div>
        <div class="txn-cat">${cat.label}</div>
      </div>
      <div class="txn-amount ${cls}">${sign}${fmt(t.amount)}</div>
    </div>`;
  }).join('');
}

// ── Modal ─────────────────────────────────────────────────────────────────────
function showModal() {
  currentType = 'income';
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal" id="modal-box">
      <div class="modal-title">Операция қосу</div>
      <div class="type-toggle">
        <button class="type-btn active-income" id="btn-income"  onclick="setType('income')">↑ Кіріс</button>
        <button class="type-btn"               id="btn-expense" onclick="setType('expense')">↓ Шығыс</button>
      </div>
      <div class="field">
        <label>Атауы</label>
        <input id="inp-name" placeholder="Мысалы: Жалақы" autocomplete="off">
      </div>
      <div class="field">
        <label>Сомасы (₸)</label>
        <input id="inp-amount" type="number" inputmode="decimal" placeholder="0" min="0">
      </div>
      <div class="field">
        <label>Санат</label>
        <select id="inp-cat">${buildCatOptions('income')}</select>
      </div>
      <button class="btn-primary" onclick="saveTransaction()">Сақтау</button>
    </div>`;
  overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('inp-name').focus(), 100);
}

function buildCatOptions(type) {
  return Object.entries(CATEGORIES)
    .filter(([, v]) => v.type === type)
    .map(([k, v]) => `<option value="${k}">${v.icon} ${v.label}</option>`)
    .join('');
}

function setType(type) {
  currentType = type;
  document.getElementById('btn-income').className  = 'type-btn' + (type === 'income'  ? ' active-income'  : '');
  document.getElementById('btn-expense').className = 'type-btn' + (type === 'expense' ? ' active-expense' : '');
  document.getElementById('inp-cat').innerHTML = buildCatOptions(type);
}

function saveTransaction() {
  const name   = document.getElementById('inp-name').value.trim() || 'Операция';
  const amount = parseFloat(document.getElementById('inp-amount').value);
  const cat    = document.getElementById('inp-cat').value;
  if (!amount || amount <= 0) { document.getElementById('inp-amount').focus(); return; }
  transactions.push({ id: Date.now(), name, category: cat, amount, type: currentType, date: new Date().toISOString() });
  save();
  closeModal();
  renderBudget();
}

function closeModal() {
  const el = document.getElementById('modal-overlay');
  if (el) el.remove();
}

// ── Investments ───────────────────────────────────────────────────────────────
function renderInvestments() {
  document.getElementById('inv-list').innerHTML = INVESTMENTS.map(inv => `
    <div class="inv-card">
      <div class="inv-header">
        <div class="inv-icon" style="background:var(--color-info-bg)">${inv.icon}</div>
        <div>
          <div class="inv-title">${inv.title}</div>
          <div class="inv-subtitle">${inv.subtitle}</div>
        </div>
      </div>
      <div class="inv-desc">${inv.desc}</div>
      <span class="risk-badge risk-${inv.risk}">${inv.riskLabel}</span>
    </div>`).join('');
}

async function askAI() {
  const inp    = document.getElementById('ai-input');
  const ansBox = document.getElementById('ai-answer');
  const btn    = document.getElementById('ai-btn');
  const q      = inp.value.trim();
  if (!q) return;

  btn.disabled = true;
  btn.textContent = '...';
  ansBox.style.display = 'block';
  ansBox.textContent = 'Жауап іздеп жатыр…';

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: 'Сіз қазақ тіліндегі қаржылық сауаттылық кеңесшісісіз. Қысқа, түсінікті қазақша жауап беріңіз (2–4 сөйлем). Техникалық терминдерді қарапайым тілде түсіндіріңіз.',
        messages: [{ role: 'user', content: q }],
      }),
    });
    const data = await res.json();
    ansBox.textContent = data.content?.map(c => c.text || '').join('') || 'Қате орын алды.';
  } catch {
    ansBox.textContent = 'Желі қатесі. Интернет байланысын тексеріңіз.';
  } finally {
    btn.disabled = false;
    btn.textContent = 'Сұра';
  }
}

// ── Stats ─────────────────────────────────────────────────────────────────────
function renderStats() {
  const income  = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const balance = income - expense;
  const savings = income > 0 ? Math.round((balance / income) * 100) : 0;

  document.getElementById('stats-grid').innerHTML = [
    { label: 'Жалпы кіріс',  val: fmt(income),   },
    { label: 'Жалпы шығыс',  val: fmt(expense),  },
    { label: 'Таза қалдық',  val: fmt(balance),  },
    { label: 'Жинақ үлесі',  val: savings + '%', },
  ].map(s => `<div class="stat-card"><div class="stat-label">${s.label}</div><div class="stat-val">${s.val}</div></div>`).join('');

  // Savings progress
  const safeRate = Math.max(0, Math.min(100, savings));
  document.getElementById('progress-fill').style.width = safeRate + '%';
  document.getElementById('progress-pct').textContent  = safeRate + '%';

  // Tips
  document.getElementById('tips-list').innerHTML = TIPS.map(t =>
    `<div class="tip-card"><div class="tip-title">💡 ${t.title}</div><div class="tip-text">${t.text}</div></div>`
  ).join('');
}

// ── Utils ─────────────────────────────────────────────────────────────────────
function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Month label
  document.getElementById('month-label').textContent =
    new Date().toLocaleDateString('kk-KZ', { month: 'long', year: 'numeric' });

  // AI enter key
  document.getElementById('ai-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') askAI();
  });

  renderBudget();
  renderInvestments();

  // Service Worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
});
